############################################################
#                                                          #
# Intel FPGA SoC Embedded ENV Command Shell                #
#                                                          #
# Source this shell script to setup your env               #
#                                                          #
#                                                          #
# Copyright (c) 2020 Intel Corporation                     #
# All Rights Reserved.                                     #
#                                                          #
############################################################


############################################################
#
# Convenience bash functions for setting up the environment
#

env_var_delete () {
    local var=${2:-PATH}
    local value
    local IFS=${3:-':'}
    for i in ${!var} ; do
        if [ "$i" != "$1" ] ; then
            value=${value:+$value:}$i
        fi
    done
    export $var="$value"
}

env_var_prepend () {
    env_var_delete "$1" "$2" "$3"
    local var=${2:-PATH}
    local sep=${3:-:}
    export $var="$1${!var:+${sep}${!var}}"
}

env_var_append () {
    env_var_delete "$1" "$2" "$3"
    local var=${2:-PATH}
    local sep=${3:-:}
    export $var="${!var:+${!var}${sep}}$1"
}
############################################################


############################################################
#
# Host Machine Environment Setup
#

if [ -z "${_IS_CYGWIN}" ]; then    
    if [ -n "${COMSPEC}" ]; then
        _IS_WINDOWS=1
    fi
    
    if [ "${_IS_WINDOWS}" = "1" ] && [ -n "$(which cygpath 2>/dev/null)" ]; then
        _IS_CYGWIN=1
    fi        
fi

_SOCEDS_IS_32BIT="0"

############################################################


############################################################
#
# Setup Quartus Prime (if you can find it)
#

if [ -n "${QUARTUS_ROOTDIR_OVERRIDE}" ]; then
    _QUARTUS_ROOTDIR="${QUARTUS_ROOTDIR_OVERRIDE}"
else
    _QUARTUS_ROOTDIR="$(cd ${SOCEDS_DEST_ROOT}/../quartus 2>/dev/null && echo $(pwd 2>/dev/null))"
    if [ -z "${_QUARTUS_ROOTDIR}" ]; then
        _QUARTUS_ROOTDIR="$(cd ${SOCEDS_DEST_ROOT}/../qprogrammer 2>/dev/null && echo $(pwd 2>/dev/null))"
    fi
    if [ -z "${_QUARTUS_ROOTDIR}" ] && [ -n "${QUARTUS_ROOTDIR}" ]; then
        _QUARTUS_ROOTDIR="${QUARTUS_ROOTDIR}"
    fi
fi

if [ -n "${_QUARTUS_ROOTDIR}" ] && [ -d "${_QUARTUS_ROOTDIR}" ]; then
   
    if [ "${_IS_CYGWIN}" = "1" ]; then
        _QUARTUS_ROOTDIR="$(cygpath -u "${_QUARTUS_ROOTDIR}" 2>/dev/null)"
    fi

   env_var_prepend "${_QUARTUS_ROOTDIR}/sopc_builder/bin"

   if [ -d "${_QUARTUS_ROOTDIR}/bin" ]; then
       env_var_prepend "${_QUARTUS_ROOTDIR}/bin"
   fi

   if [ -d "${_QUARTUS_ROOTDIR}/bin64" ]; then
       env_var_prepend "${_QUARTUS_ROOTDIR}/bin64"
   fi

   # Set QUARTUS_ROOTDIR because DS-5 requires this to find jtag libraries
   if [ "${_IS_CYGWIN}" = "1" ]; then
       export QUARTUS_ROOTDIR="$(cygpath -m "${_QUARTUS_ROOTDIR}" 2>/dev/null)"
   else
       export QUARTUS_ROOTDIR="${_QUARTUS_ROOTDIR}"
   fi

fi

unset _QUARTUS_ROOTDIR
############################################################


############################################################
#
# Setup Nios2eds (if you can find it)
#

if [ -n "${SOPC_KIT_NIOS2_OVERRIDE}" ]; then
	_SOPC_KIT_NIOS2=${SOPC_KIT_NIOS2_OVERRIDE}
elif [ -n "${QUARTUS_ROOTDIR}" ]; then
        _SOPC_KIT_NIOS2="$(cd ${QUARTUS_ROOTDIR}/../nios2eds 2>/dev/null && echo $(pwd 2>/dev/null))"
fi

if [ -n "${_SOPC_KIT_NIOS2}" ]; then
    if [ "${_IS_CYGWIN}" = "1" ]; then
        _SOPC_KIT_NIOS2="$(cygpath -u "${_SOPC_KIT_NIOS2}" 2>/dev/null)"
    fi
    
    env_var_prepend "${_SOPC_KIT_NIOS2}/bin"
    env_var_prepend "${_SOPC_KIT_NIOS2}/sdk2/bin"
    
    if [ "${_IS_WINDOWS}" = "1" ]; then
        if [ "${_SOCEDS_IS_32BIT}" = "1" ]; then
            env_var_prepend "${_SOPC_KIT_NIOS2}/bin/gnu/H-i686-mingw32/bin"
        else
            env_var_prepend "${_SOPC_KIT_NIOS2}/bin/gnu/H-x86_64-mingw32/bin"
        fi
    else	
        if [ "${_SOCEDS_IS_32BIT}" = "1" ]; then
            env_var_prepend "${_SOPC_KIT_NIOS2}/bin/gnu/H-i686-pc-linux-gnu/bin"
        else
            env_var_prepend "${_SOPC_KIT_NIOS2}/bin/gnu/H-x86_64-pc-linux-gnu/bin"
        fi
    fi
    
    if [ "${_IS_CYGWIN}" = "1" ]; then
        export SOPC_KIT_NIOS2="$(cygpath -m "${_SOPC_KIT_NIOS2}" 2>/dev/null)"
    else
        export SOPC_KIT_NIOS2="${_SOPC_KIT_NIOS2}"
    fi
    
    unset _SOPC_KIT_NIOS2
fi
############################################################


############################################################
#
# SoCEDS Environment setup
#

if [ -n "${SOCEDS_DEST_ROOT}" ]; then
    
    _SOCEDS_DEST_ROOT="${SOCEDS_DEST_ROOT}"
    
    if [ "${_IS_CYGWIN}" = "1" ]; then
        _SOCEDS_DEST_ROOT="$(cygpath -u "${_SOCEDS_DEST_ROOT}" 2>/dev/null)"
    fi

    if [ "${_IS_WINDOWS}" = "1" ] || [ "${_IS_CYGWIN}" = "1" ]; then
        _PYTHON_HOSTOS_OFFSET="host_tools/python"
    else
        _PYTHON_HOSTOS_OFFSET="host_tools/python/bin"
    fi

    #export ARM_TOOL_VARIANT=altera
    #export ARM_TOOL_VARIANT=eval_alt
    #export ARM_TOOL_VARIANT=pro
    #export ARM_TOOL_VARIANT=ds5eval
    #export ARM_TOOL_VARIANT=ult
    #export ARM_TOOL_VARIANT=ulteval

    if [ -z "${ARM_TOOL_VARIANT}" ]; then
       # Set default toolchain variant here
       # export ARM_TOOL_VARIANT=altera
       :
    fi
    
    if [ "${ARM_TOOL_VARIANT}" == "pro" ]; then
        unset ARM_TOOL_VARIANT
    fi

    # Add python to the global PATH only if you're on windows or USE_SOCEDS_PYTHON env var is set to 1 
    if [ "${USE_SOCEDS_PYTHON}" = "1" ] || [ "${_IS_WINDOWS}" = "1" ] || [ "${_IS_CYGWIN}" = "1" ]; then
        env_var_prepend "${_SOCEDS_DEST_ROOT}/${_PYTHON_HOSTOS_OFFSET}"
    fi

    # Add device tree compiler to PATH
    env_var_prepend "${_SOCEDS_DEST_ROOT}/host_tools/gnu/dtc"
  
    env_var_prepend "${_SOCEDS_DEST_ROOT}/host_tools/altera/secureboot"
    env_var_prepend "${_SOCEDS_DEST_ROOT}/host_tools/altera/imagecat"
    env_var_prepend "${_SOCEDS_DEST_ROOT}/host_tools/altera/diskutils"
    env_var_prepend "${_SOCEDS_DEST_ROOT}/host_tools/altera/device_tree"
    env_var_prepend "${_SOCEDS_DEST_ROOT}/host_tools/altera/mkpimage"
    env_var_prepend "${_SOCEDS_DEST_ROOT}/host_tools/altera/mkimage"
    env_var_prepend "${_SOCEDS_DEST_ROOT}/host_tools/altera/preloadergen"

    # prepend mingw gnu make to PATH
    if [ "${_IS_WINDOWS}" = "1" ]; then
        if [ "${_SOCEDS_IS_32BIT}" = "1" ]; then
            env_var_prepend "${_SOCEDS_DEST_ROOT}/host_tools/gnu/make/H-i686-pc-mingw32/bin"
        else
            env_var_prepend "${_SOCEDS_DEST_ROOT}/host_tools/gnu/make/H-x86_64-mingw32/bin"
        fi
    fi

    env_var_prepend "${_SOCEDS_DEST_ROOT}/host_tools/linaro/gcc/bin"

    unset _DS5_BINDIR
    unset _DS5_ROOT
    unset _PYTHON_HOSTOS_OFFSET
    unset _SOCEDS_DEST_ROOT
else
    echo "ERROR: SOCEDS_DEST_ROOT not set"
fi
############################################################


############################################################

if [ -z "${QUARTUS_ROOTDIR}" ]; then
    echo "WARNING: QUARTUS_ROOTDIR is not set and could not be discovered. USB Blaster Support for DS-5 will not function if QUARTUS_ROOTDIR is not set to a valid Quartus Prime installation." 1>&2
fi


unset _IS_WINDOWS
unset _IS_CYGWIN
unset _SOCEDS_IS_32BIT

############################################################
